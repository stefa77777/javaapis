const API_URL = 'http://localhost:8080/api/envios';

function cargarEnvios(page = 0, size = 5){
    fetch(`${API_URL}?page=${page}&size=${size}&sortBy=id&sortDirection=ASC`)
        .then(response => {
            if(!response.ok){
                throw new Error(`Error HTTP: ${response.status}`);
            }
            return response.json();
        })
        .then(data =>{
            mostrarEnvios(data.content);
            mostrarPaginacion(data);
        })
        .catch(error=>{
            console.error('Error: ', error);
            alert('No se pudo conectar con el servidor')
        });
}

function mostrarEnvios(envios){
    const lista = document.getElementById('enviosLista');
    lista.innerHTML = '';
    envios.forEach(envio => {
        const li = document.createElement('li');
        li.className = 'envio-item'; 
        li.innerHTML = `
        <strong>${envio.cliente}</strong> -> ${envio.destino} (${envio.estado}) - $${envio.costo}
        `;
        lista.appendChild(li);
    });
}

function mostrarPaginacion(data){
    const paginacion = document.getElementById('paginacion');
    paginacion.innerHTML = `
    <button onclick="cargarEnvios(${data.number - 1})" ${data.first ?
         'disabled' : ''}>Anterior</button>
    <span> Pagina ${data.number + 1} de ${data.totalPages}</span>
    <button onclick="cargarEnvios(${data.number + 1})" ${data.last ?
         'disabled' : ''}>Siguiente</button>
    `;
}

function crearEnvio(event){
    event.preventDefault();

    const nuevoEnvio ={
        cliente : document.getElementById('cliente').value,
        destino : document.getElementById('destino').value,
        pesoKg : parseFloat(document.getElementById('pesoKg').value)
    };


    fetch(API_URL,{
        method: 'POST',
        headers: {'Content-Type' : 'application/json'},
        body: JSON.stringify(nuevoEnvio)
    })
    .then(response => response.json())
    .then(envioCreado => {
        alert('Envio creado');
        cargarEnvios();
        document.getElementById('envioForm').reset();
    })
    .catch(error => console.error('Error: ', error));
}


document.addEventListener('DOMContentLoaded', () => {
    cargarEnvios();
    document.getElementById('envioForm').addEventListener('submit',
        crearEnvio)
});